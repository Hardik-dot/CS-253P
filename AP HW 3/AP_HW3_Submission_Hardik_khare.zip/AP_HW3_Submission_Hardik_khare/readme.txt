javac parseCpp.java
java parseCpp
Enter File location
sample.cpp
