hardikkhare@Hardiks-MacBook-Pro AP HW 5 % javac AVLTree.java
hardikkhare@Hardiks-MacBook-Pro AP HW 5 % java AVLTree

Enter choice (insert/delete/find/quit):
insert 5
5 (inserted)
Enter choice (insert/delete/find/quit):
find 5
5 (found)
Enter choice (insert/delete/find/quit):
delete 5
5  (deleted)
Enter choice (insert/delete/find/quit):
quit
